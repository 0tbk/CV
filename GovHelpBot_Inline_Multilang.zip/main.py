
from aiogram import Bot, Dispatcher, types
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils import executor
from aiogram.contrib.fsm_storage.memory import MemoryStorage

API_TOKEN = 'PASTE_YOUR_TOKEN_HERE'

bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot, storage=MemoryStorage())

user_lang = {}

def get_main_menu(lang='ru'):
    if lang == 'ru':
        return InlineKeyboardMarkup(row_width=2).add(
            InlineKeyboardButton("ID-карта", callback_data="id"),
            InlineKeyboardButton("ИНН (СТИР)", callback_data="stir"),
            InlineKeyboardButton("Справка", callback_data="spravka"),
            InlineKeyboardButton("Кадастр", callback_data="kadastr"),
            InlineKeyboardButton("Соц. помощь", callback_data="reyestr"),
            InlineKeyboardButton("Загранпаспорт", callback_data="zagran"),
            InlineKeyboardButton("Сменить язык: 🇺🇿", callback_data="lang_uz")
        )
    else:
        return InlineKeyboardMarkup(row_width=2).add(
            InlineKeyboardButton("ID-karta", callback_data="id"),
            InlineKeyboardButton("STIR", callback_data="stir"),
            InlineKeyboardButton("Ma'lumotnoma", callback_data="spravka"),
            InlineKeyboardButton("Kadastr", callback_data="kadastr"),
            InlineKeyboardButton("Ijtimoiy yordam", callback_data="reyestr"),
            InlineKeyboardButton("Zagranpasport", callback_data="zagran"),
            InlineKeyboardButton("Tilni almashtirish: 🇷🇺", callback_data="lang_ru")
        )

@dp.message_handler(commands=['start'])
async def start_cmd(message: types.Message):
    user_lang[message.from_user.id] = 'ru'
    await message.answer("Добро пожаловать в GovHelpBot! Выберите нужную услугу:", reply_markup=get_main_menu('ru'))

@dp.callback_query_handler(lambda c: c.data.startswith('lang'))
async def change_lang(callback_query: types.CallbackQuery):
    lang = 'uz' if callback_query.data == 'lang_uz' else 'ru'
    user_lang[callback_query.from_user.id] = lang
    await callback_query.message.edit_text(
        "Til tanlandi!" if lang == 'uz' else "Язык выбран!",
        reply_markup=get_main_menu(lang)
    )

@dp.callback_query_handler(lambda c: True)
async def process_menu(callback_query: types.CallbackQuery):
    uid = callback_query.from_user.id
    lang = user_lang.get(uid, 'ru')
    data = callback_query.data

    responses = {
        'id': {
            'ru': "Оформить ID-карту: https://my.gov.uz/ru/service/378",
            'uz': "ID-karta olish: https://my.gov.uz/ru/service/378"
        },
        'stir': {
            'ru': "Получить ИНН (СТИР): https://my.soliq.uz",
            'uz': "STIR olish: https://my.soliq.uz"
        },
        'spravka': {
            'ru': "Справка из наркодиспансера: https://my.gov.uz/ru/service/476",
            'uz': "Narkologik dispanserdan ma'lumotnoma: https://my.gov.uz/ru/service/476"
        },
        'reyestr': {
            'ru': "Заявка в социальный реестр: https://my.gov.uz/ru/service/599",
            'uz': "Ijtimoiy reyestr uchun ariza: https://my.gov.uz/ru/service/599"
        },
        'kadastr': {
            'ru': "Оформление кадастра: https://my.gov.uz/ru/service/122",
            'uz': "Kadastr rasmiylashtirish: https://my.gov.uz/ru/service/122"
        },
        'zagran': {
            'ru': "Оформить загранпаспорт: https://my.gov.uz/ru/service/472",
            'uz': "Zagranpasport olish: https://my.gov.uz/ru/service/472"
        }
    }

    text = responses.get(data, {}).get(lang, "Выберите услугу:")
    await callback_query.answer()
    await callback_query.message.answer(text, reply_markup=get_main_menu(lang))

if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)
